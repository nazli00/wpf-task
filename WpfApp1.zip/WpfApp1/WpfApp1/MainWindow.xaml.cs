﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Random random = new Random();
        int buttonSerial = 1;
        public MainWindow()
        {
            InitializeComponent();
        }
        private void ChangeColorAndShowInfo(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            Color randomColor = Color.FromRgb((byte)random.Next(256), (byte)random.Next(256), (byte)random.Next(256));
            button.Background = new SolidColorBrush(randomColor);

            MessageBox.Show($"{button.Content}: Color changed to {randomColor}.");
        }

        private void DeleteButton(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Right)
            {
                Button button = (Button)sender;
                button.Width = 0;
                button.Height = 0;
                MessageBox.Show($"{button.Content} deleted.");
                button.Content = "";
                
            }
        }
    }
}
